// Extrator de produtos — Mercado Livre + Shopee (Netlify Function v2)
const UA_MOBILE = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36';
const UA_BOT = 'facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)';
const ALLOWED = ['mercadolivre.com.br', 'mercadolivre.com', 'mercadolibre.com', 'meli.la', 'shopee.com.br', 'shopee.com', 'shp.ee', 'shope.ee', 'shein.com', 'shein.com.br', 'shein.top'];

const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json; charset=utf-8' } });
const hostOf = (u) => { try { return new URL(u).hostname.toLowerCase(); } catch { return ''; } };
const allowed = (u) => { const h = hostOf(u); return ALLOWED.some((d) => h === d || h.endsWith('.' + d)); };
const isML = (u) => /mercadoli|meli\.la/.test(hostOf(u));
const isShein = (u) => /shein/.test(hostOf(u));
const isShopee = (u) => /shopee|shp\.ee|shope\.ee/.test(hostOf(u));

const dec = (s) => String(s || '')
  .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, "'")
  .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)))
  .replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(+d));
const clean = (s) => dec(s).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();

function brl(n) {
  const v = Number(n);
  if (!isFinite(v) || v <= 0) return '';
  const [i, d] = v.toFixed(2).split('.');
  return 'R$ ' + i.replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ',' + d;
}

async function get(url, { ua = UA_MOBILE, headers = {}, hops = 6, timeout = 7000 } = {}) {
  let cur = url;
  for (let i = 0; i <= hops; i++) {
    if (!allowed(cur)) throw new Error('Link de site não suportado. Use links do Mercado Livre, Shopee ou Shein.');
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), timeout);
    let res;
    try {
      res = await fetch(cur, {
        redirect: 'manual', signal: ctl.signal,
        headers: { 'user-agent': ua, 'accept-language': 'pt-BR,pt;q=0.9,en;q=0.5', accept: 'text/html,application/json;q=0.9,*/*;q=0.8', ...headers },
      });
    } finally { clearTimeout(t); }
    const loc = res.headers.get('location');
    if (res.status >= 300 && res.status < 400 && loc) { cur = new URL(loc, cur).href; continue; }
    return { res, url: cur, text: await res.text() };
  }
  throw new Error('Redirecionamentos demais.');
}

function meta(html, key) {
  const k = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const a = html.match(new RegExp(`<meta[^>]+(?:property|name|itemprop)=["']${k}["'][^>]*content=["']([^"']*)["']`, 'i'));
  const b = html.match(new RegExp(`<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name|itemprop)=["']${k}["']`, 'i'));
  return dec((a || b || [])[1] || '');
}

function ldProduct(html) {
  for (const m of html.matchAll(/<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi)) {
    try {
      const j = JSON.parse(m[1]);
      const arr = Array.isArray(j) ? j : (j['@graph'] || [j]);
      const p = arr.find((x) => x && /Product/.test([].concat(x['@type'] || []).join()));
      if (p) return p;
    } catch { /* ignora */ }
  }
  return null;
}

function fromHtml(html, link, marketplace) {
  const p = ldProduct(html);
  const o = p && (Array.isArray(p.offers) ? p.offers[0] : p.offers);
  let title = clean((p && p.name) || meta(html, 'og:title') || (html.match(/<title>([\s\S]*?)<\/title>/i) || [])[1] || '');
  title = title.replace(/\s*[|\-–]\s*(Mercado\s?Livre|Shopee.*)$/i, '').trim();
  const description = clean((p && p.description) || meta(html, 'og:description') || meta(html, 'description'));
  const priceRaw = (o && (o.price ?? o.lowPrice)) ?? meta(html, 'product:price:amount') ?? meta(html, 'price');
  const images = [...new Set([]
    .concat((p && p.image) || [], meta(html, 'og:image') || [])
    .map((x) => (typeof x === 'string' ? x : x && x.url))
    .filter(Boolean))].slice(0, 12);
  const cur = ((o && o.priceCurrency) || meta(html, 'product:price:currency') || meta(html, 'og:price:currency') || 'BRL').toUpperCase();
  const num = Number(String(priceRaw || '').replace(',', '.'));
  const price = !num ? '' : (cur === 'BRL' ? brl(num) : `${cur} ${num.toFixed(2)}`);
  return { marketplace, title, description, price, link, images, shopId: '', itemId: '', status: 'ok' };
}

/* ---------- Mercado Livre ---------- */
function mlListing(html, link) {
  const parts = html.split(/<(?:div|li)[^>]*class="[^"]*\bpoly-card\b[^"]*"/).slice(1);
  const out = [];
  for (const c of parts) {
    const a = c.match(/<a[^>]*class="[^"]*poly-component__title[^"]*"[^>]*>/) || c.match(/<a[^>]*href="[^"]+"[^>]*class="[^"]*poly-component__title/);
    if (!a) continue;
    const href = (a[0].match(/href="([^"]+)"/) || [])[1];
    const after = c.slice(c.indexOf(a[0]) + a[0].length);
    const title = clean(after.split('</a>')[0]);
    if (!href || !title) continue;
    const cur = c.indexOf('poly-price__current');
    const seg = cur >= 0 ? c.slice(cur) : c;
    const frac = (seg.match(/andes-money-amount__fraction[^>]*>([\d.]+)</) || [])[1];
    const cents = (seg.match(/andes-money-amount__cents[^>]*>(\d+)</) || [])[1] || '00';
    const img = (c.match(/<img[^>]+(?:data-src|src)="(https:\/\/http2\.mlstatic\.com[^"]+)"/) || [])[1] || '';
    out.push({
      marketplace: 'Mercado Livre', title, description: '',
      price: frac ? brl(frac.replace(/\./g, '') + '.' + cents) : '',
      link: dec(href), canonical: dec(href).split('?')[0].split('#')[0], images: img ? [dec(img)] : [], shopId: '', itemId: ((href.match(/MLB-?(\d+)/) || [])[1]) || '', status: 'ok',
    });
  }
  return out;
}

async function extractML(input) {
  let { text, url } = await get(input);
  const isProduct = (t) => !!ldProduct(t) || /og:title/.test(t) && /MLB-?\d+/.test(t);
  // Link de afiliado (meli.la / /social/ / página intermediária): procura o link real do produto
  for (let k = 0; k < 2 && !isProduct(text) && !/poly-card/.test(text); k++) {
    const all = [...text.matchAll(/https?:\\?\/\\?\/[a-z0-9.-]*mercadoli[a-z]+\.com(?:\.br)?[^"'\s<>]*/gi)].map((m) => dec(m[0].replace(/\\\//g, '/').replace(/\\u002F/gi, '/')));
    const cand = all.find((u) => /MLB-?\d+|\/p\/MLB/.test(u) && u !== url);
    if (!cand) break;
    ({ text, url } = await get(cand));
  }
  if (/poly-card/.test(text) && !ldProduct(text)) {
    const list = mlListing(text, input);
    if (list.length) return list;
  }
  const p = fromHtml(text, input, 'Mercado Livre');
  p.itemId = (url.match(/MLB-?(\d+)/) || text.match(/MLB-?(\d{6,})/) || [])[1] || '';
  p.canonical = url.split('#')[0].split('?')[0];
  if (!p.title || /^(mercado\s?livre|acesse sua conta|verificando)/i.test(p.title)) {
    throw new Error('O Mercado Livre não devolveu os dados deste anúncio (bloqueio ou link inválido). Tente o link completo do produto.');
  }
  return [p];
}

/* ---------- Shein (melhor esforço: o site tem proteção forte contra robôs) ---------- */
async function extractShein(input) {
  let last = null;
  for (const ua of [UA_MOBILE, UA_BOT]) {
    try {
      const r = await get(input, { ua, timeout: 6500 });
      const p = fromHtml(r.text, input, 'Shein');
      p.title = p.title.replace(/\s*[|\-–]\s*SHEIN.*$/i, '').trim();
      p.itemId = (r.url.match(/-p-(\d+)/) || input.match(/-p-(\d+)/) || [])[1] || '';
      if (p.title && !/^(shein|access denied|just a moment|robot)/i.test(p.title)) return [p];
    } catch (e) { last = e; }
  }
  throw new Error((last && last.name !== 'AbortError' && last.message) || 'A Shein bloqueou a leitura automática deste produto. Tente o link completo (com -p-números) ou use a Shopee/Mercado Livre.');
}

/* ---------- Shopee ---------- */
function shopeeIds(s) {
  let str = s;
  try { str = decodeURIComponent(s); } catch { /* mantém */ }
  const m = str.match(/-i\.(\d+)\.(\d+)/) || str.match(/\/product\/(\d+)\/(\d+)/) || str.match(/shop_?id=(\d+)[^]*?item_?id=(\d+)/i);
  return m ? { shopId: m[1], itemId: m[2] } : null;
}
const shImg = (id) => (/^https?:/.test(id) ? id : `https://down-br.img.susercontent.com/file/${id}`);

function fromShopeeApi(j, link, ids) {
  const it = (j && j.data && (j.data.item || j.data)) || null;
  if (!it || !(it.name || it.title)) return null;
  const raw = it.price_min ?? it.price ?? (it.price_info && it.price_info.price) ?? 0;
  const imgs = [].concat(it.images || [], it.image ? [it.image] : []);
  return {
    marketplace: 'Shopee', title: clean(it.name || it.title), description: clean(it.description || ''),
    price: brl(raw / 100000), link, images: [...new Set(imgs.map(shImg))].slice(0, 12),
    shopId: ids.shopId, itemId: ids.itemId, status: 'ok',
  };
}

async function extractShopee(input) {
  let ids = shopeeIds(input);
  let page = null;
  if (!ids) {
    page = await get(input, { ua: UA_BOT });
    ids = shopeeIds(page.url) || shopeeIds(page.text);
  }
  if (!ids) throw new Error('Não encontrei o produto neste link da Shopee. Abra o produto no navegador e copie o link completo.');

  const q = `itemid=${ids.itemId}&shopid=${ids.shopId}`;
  const prod = `https://shopee.com.br/product/${ids.shopId}/${ids.itemId}`;
  const apiHeaders = { referer: prod, 'x-api-source': 'pc', 'x-requested-with': 'XMLHttpRequest', accept: 'application/json' };
  for (const api of [
    `https://shopee.com.br/api/v4/pdp/get_pc?item_id=${ids.itemId}&shop_id=${ids.shopId}&tz_offset_minutes=-180&detail_level=0`,
    `https://shopee.com.br/api/v4/item/get?${q}`,
  ]) {
    try {
      const r = await get(api, { headers: apiHeaders, timeout: 5000 });
      const p = r.res.ok && fromShopeeApi(JSON.parse(r.text), input, ids);
      if (p) return [p];
    } catch { /* tenta o próximo */ }
  }
  // Plano B: metadados da página (Open Graph) com user-agent de pré-visualização
  try {
    const r = page && page.url.includes('shopee') && /og:title/.test(page.text) ? page : await get(prod, { ua: UA_BOT, timeout: 6000 });
    const p = fromHtml(r.text, input, 'Shopee');
    if (p.title && !/^shopee/i.test(p.title)) { p.shopId = ids.shopId; p.itemId = ids.itemId; return [p]; }
  } catch { /* cai no erro abaixo */ }
  throw new Error('A Shopee bloqueou a leitura deste produto. Tente novamente em instantes ou use o link completo.');
}

export default async (req) => {
  if (req.method !== 'POST') return json(405, { error: 'Método não permitido.' });
  let url;
  try { ({ url } = await req.json()); } catch { return json(400, { error: 'Requisição inválida.' }); }
  url = String(url || '').trim();
  if (!/^https?:\/\//i.test(url)) return json(400, { error: 'Cole um link completo começando com https://' });
  try {
    if (isShopee(url)) return json(200, { products: await extractShopee(url) });
    if (isShein(url)) return json(200, { products: await extractShein(url) });
    if (isML(url)) return json(200, { products: await extractML(url) });
    return json(400, { error: 'Link não suportado. Use links do Mercado Livre, Shopee ou Shein.' });
  } catch (e) {
    return json(502, { error: e.name === 'AbortError' ? 'Tempo esgotado ao abrir o link.' : e.message });
  }
};
